<?php
/**
 * Created by PhpStorm.
 * User: A
 * Date: 2018/11/19
 * Time: 22:56
 */

/**
 *
 Bt-Panel: http://47.99.65.128:8888/641982df
username: vtyz4pip
password: 4212c233
 *
 *
 *
 *

 *
 *
 *
 *
 *
 百度api
 *
 * 时光机1856   cc7162534

 *
 *
 * 17300668520@163.com
 * cc7162534

 *
 *
 * appid: wx5d68fecad5b54475
 *
 * AppSecret: 8457a179590528036c191b479672d23e
 *
 *
 *
 *
 *
 *
 */

//图像生成文章  https://laravel-china.org/articles/18418

//todo  头像审核   短信模板    确认信息表单字段

//todo 双方互为心动    加入心动时先检测对方是否把自己加为心动，如果加入，则自己加一条心动记录  is_hu 为1，并更新对方数据的 is_hu 为1 ，