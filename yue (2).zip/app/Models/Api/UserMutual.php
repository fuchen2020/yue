<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class UserMutual extends Model
{
    //

    protected $table = 'user_mutual_xd';
}
