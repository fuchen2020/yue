<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class UserOrder extends Model
{
    //

    protected $table = 'user_order';
}
