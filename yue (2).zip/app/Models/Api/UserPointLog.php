<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class UserPointLog extends Model
{

    protected $table = 'user_point_log';
}
