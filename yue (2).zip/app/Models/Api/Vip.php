<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class Vip extends Model
{
    //

    protected $table ='vip';
}
