<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class NewGuide extends Model
{

    protected $table = 'new_guide';

}
