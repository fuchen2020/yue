<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class UserExtend extends Model
{
    //
    protected $table ='user_extend';
}
