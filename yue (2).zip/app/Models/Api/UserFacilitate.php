<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class UserFacilitate extends Model
{
    //

    protected $table ='user_facilitate';
}
