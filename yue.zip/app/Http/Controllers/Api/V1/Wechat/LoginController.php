<?php
/**
 * Created by PhpStorm.
 * User: A
 * Date: 2018/11/21
 * Time: 22:42
 */

namespace App\Http\Controllers\Api\V1\Wechat;


use App\Http\Components\Code;
use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;

class LoginController extends BaseController
{
    /**
     * 用户登录
     * @param Request $request
     * @return LoginController|\Illuminate\Http\JsonResponse
     */
   public function login(Request $request){

       try{

           if ($request->input('id')) {

               $user['id']= $request->id;

               $token=auth()->tokenById($user['id']);

               return response()->json([
                   'code' => 200,
                   'msg' => '登录成功!',
                   'status' => true,
                   'data' => [
                       'token'=> $token
                   ]
               ]);

           }

        
       }catch (\Exception $exception){

           return $this->sendError(Code::FAIL, $exception->getMessage());
       }

   }





}