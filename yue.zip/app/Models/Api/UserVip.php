<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class UserVip extends Model
{
    //

    protected $table = 'user_vip';
}
