<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    //

    protected $table='banner';
}
