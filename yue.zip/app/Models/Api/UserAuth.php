<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class UserAuth extends Model
{
    //
    protected $table='user_auth';

}
